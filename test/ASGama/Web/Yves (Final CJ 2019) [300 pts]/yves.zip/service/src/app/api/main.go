package main

import (
	"log"
	"net/http"
	"time"

	"yves"
)

func main() {
	app := yves.NewYves()
	log.Println("Yves will listen at port 31337")

	srv := &http.Server{
		Handler:      app.Router,
		Addr:         ":31337",
		WriteTimeout: 15 * time.Second,
		ReadTimeout:  15 * time.Second,
	}
	log.Fatal(srv.ListenAndServe())
}
