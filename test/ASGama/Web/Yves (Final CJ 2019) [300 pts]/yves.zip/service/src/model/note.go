package model

type Note struct {
	ID      uint64 `json:"id" gorm:"primary_key;type:bigint"`
	Content string `json:"content" gorm:"type:varchar(255)";not null`
	UserID  uint64 `json:"-"`
	User    User   `json:"-"`
}
