package api

import (
	"encoding/json"
	"fmt"
	"net/http"
	"regexp"

	"github.com/go-sql-driver/mysql"
	"github.com/gorilla/mux"

	"yves/database"
	"yves/model"
	"yves/response"
)

var (
	usernameRegex = regexp.MustCompile("^[A-Za-z0-9]{3,20}$")
)

func (h Handler) GetUser(w http.ResponseWriter, r *http.Request) {
	username := mux.Vars(r)["username"]

	var user model.User
	if database.MySQL.Where("username = ?", username).First(&user).RecordNotFound() {
		response.Write(w, response.BuildError(response.ErrNotFound), http.StatusNotFound)
		return
	}
	response.Write(w, response.BuildSuccess(user), http.StatusOK)
}

func (h Handler) Register(w http.ResponseWriter, r *http.Request) {
	defer r.Body.Close()

	var userRequest model.User
	err := json.NewDecoder(r.Body).Decode(&userRequest)
	if err != nil {
		response.Write(w, response.BuildError(err), http.StatusBadRequest)
		return
	}

	user := model.User{
		Username: userRequest.Username,
		Password: userRequest.Password,
	}
	err = validateRegister(user)
	if err != nil {
		response.Write(w, response.BuildError(err), http.StatusUnprocessableEntity)
		return
	}

	if result := database.MySQL.Create(&user); result.Error != nil {
		sqlErr, ok := result.Error.(*mysql.MySQLError)
		if ok {
			if sqlErr.Number == 1062 {
				err = fmt.Errorf("User already exists")
				response.Write(w, response.BuildError(err), http.StatusUnprocessableEntity)
				return
			}
		}
		response.Write(w, response.BuildError(response.ErrInternalServerError), http.StatusInternalServerError)
		return
	}

	response.Write(w, response.BuildSuccess(nil), http.StatusCreated)
}

func validateRegister(user model.User) error {
	if !usernameRegex.MatchString(user.Username) {
		return fmt.Errorf("Username must be alphanumeric with 3-20 characters")
	}
	return nil
}
