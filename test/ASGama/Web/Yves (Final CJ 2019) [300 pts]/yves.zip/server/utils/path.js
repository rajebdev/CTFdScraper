const url = require('url');

exports.baseURL = 'http://service:31337/api/';
exports.joinPath = function(baseURL, path) {
    return url.resolve(baseURL, path);
}
