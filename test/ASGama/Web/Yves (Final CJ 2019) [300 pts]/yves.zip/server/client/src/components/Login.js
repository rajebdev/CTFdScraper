import React, { useContext } from 'react';
import { Link as RouterLink, withRouter } from 'react-router-dom';

import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Link from '@material-ui/core/Link';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';

import { AuthContext } from '../contexts/AuthContext';
import { NotificationContext } from '../contexts/NotificationContext';
import { login } from '../utils/Api';

const useStyles = makeStyles(theme => ({
  paper: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  form: {
    width: '100%', // Fix IE 11 issue.
    marginTop: theme.spacing(1),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
}));

function Login(props) {
  const classes = useStyles();
  const { setToken, setUser } = useContext(AuthContext);
  const { setNotification } = useContext(NotificationContext);

  async function handleSubmit(event) {
    event.preventDefault();
    const username = event.target.username.value;
    const password = event.target.password.value;
    try {
      const token = await login(username, password);
      setToken(token);
      setUser({username});
      setNotification({
        variant: 'success',
        message: 'Successfully logged in',
      });
      props.history.push(`/`);
    } catch (error) {
      if (error.response) {
        setNotification({
          variant: 'error',
          message: error.response.data.errors,
        });
      } else {
        setNotification({
          variant: 'error',
          message: error,
        });
      }
    }
  }

  return (
    <Container component="main" maxWidth="xs">
      <div className={classes.paper}>
        <form className={classes.form} onSubmit={handleSubmit}>
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            id="username"
            label="Username"
            name="username"
            autoFocus
          />
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            id="password"
            name="password"
            type="password"
            label="Password"
          />
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className={classes.submit}
          >
            Login
          </Button>
          <Link variant="body2" component={RouterLink} to="/register">
            {"Don't have an account? Register"}
          </Link>
        </form>
      </div>
    </Container>
  );
}

export default withRouter(Login);
