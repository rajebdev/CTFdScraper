import React, { createContext, useEffect, useState } from 'react';

export const NotificationContext = createContext();

export default function ({ children }) {
  const [notification, setNotification] = useState({ variant: 'error', message: '' });
  const [notificationOpen, setNotificationOpen] = useState(false);

  useEffect(() => {
    if (notification.variant && notification.message) {
      setNotificationOpen(true);
    } else {
      setNotificationOpen(false);
    }
  }, [notification]);

  const defaultContext = {
    notification,
    setNotification,
    notificationOpen,
    setNotificationOpen,
  };

  return (
    <NotificationContext.Provider value={defaultContext}>
      {children}
    </NotificationContext.Provider>
  );
};
