import axios from 'axios';

axios.defaults.baseURL = `/api`;

export async function register(username, password) {
  return await axios.post(`/register`, {
    username,
    password,
  });
}

export async function login(username, password) {
  let token = null;
  try {
    const result = await axios.post(`/login`, {
      username,
      password,
    });
    token = result.data.data.token;
  } catch (error) {
    throw error;
  }
  return token;
}

export async function getNotes() {
  const result = await axios.get(`/notes`);
  return result.data.data;
}

export async function createNote(content) {
  return await axios.post(`/notes`, {content});
}
