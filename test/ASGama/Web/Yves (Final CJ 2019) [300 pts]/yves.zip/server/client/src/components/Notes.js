import React, { useEffect, useState, useContext } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Fab from '@material-ui/core/Fab';
import AddIcon from '@material-ui/icons/Add';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';

import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import TextField from '@material-ui/core/TextField';

import Button from '@material-ui/core/Button';

import { AuthContext } from '../contexts/AuthContext';
import { NotificationContext } from '../contexts/NotificationContext';
import { getNotes, createNote } from '../utils/Api';

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1,
  },
  extendedIcon: {
    marginRight: theme.spacing(1),
  }
}));

async function fetchNotes(setNotes) {
  try {
    const notes = await getNotes();
    setNotes(notes);
  } catch (error) {
    setNotes([]);
  }
}

export default function Notes() {
  const classes = useStyles();

  const { user } = useContext(AuthContext);
  const { setNotification } = useContext(NotificationContext);

  const [notes, setNotes] = useState([]);
  useEffect(() => {
    if (user) {
      fetchNotes(setNotes);
    } else {
      setNotes([]);
    }
  }, [user]);

  const [note, setNote] = useState('');
  async function handleNoteChange(event) {
    setNote(event.target.value);
  }

  const [openDialog, setOpenDialog] = useState(false);
  async function handleDialogOpen() {
    setOpenDialog(true);
  }
  async function handleDialogClose() {
    setOpenDialog(false);
  }
  async function handleDialogSubmit() {
    try {
      await createNote(note);
      const notes = await getNotes();
      setNotes(notes);
    } catch (error) {
      setNotification({
        variant: 'error',
        message: error.response ? error.response.data.errors : error,
      });
    }
    handleDialogClose();
  }

  return (
    <div className={classes.root}>
      {user &&
        <Fab
          variant="extended"
          color="primary"
          aria-label="add"
          onClick={handleDialogOpen}
        >
          <AddIcon className={classes.extendedIcon} />
          Create
        </Fab>
      }
      <List>
        {notes.map(note =>
          <ListItem key={note.id}>
            <ListItemText primary={note.content}></ListItemText>
          </ListItem>
        )}
      </List>
      <Dialog
        fullWidth
        maxWidth="sm"
        aria-labelledby="form-dialog-title"
        open={openDialog}
        onClose={handleDialogClose}
      >
        <DialogTitle id="form-dialog-title">Create note</DialogTitle>
        <DialogContent>
          <TextField
            id="note"
            label="What's on your mind?"
            autoFocus
            fullWidth
            multiline
            onChange={handleNoteChange}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDialogClose} color="primary">
            Cancel
          </Button>
          <Button onClick={handleDialogSubmit} color="primary">
            Create
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
