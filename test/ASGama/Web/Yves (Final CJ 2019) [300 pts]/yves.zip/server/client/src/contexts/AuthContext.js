import React, { createContext, useEffect, useState } from 'react';
import axios from 'axios';
import jwtDecode from 'jwt-decode';

export const AuthContext = createContext();

const tokenName = 'yves_token';

export default function ({ children }) {
  const [token, setToken] = useState(window.localStorage.getItem(tokenName) || null);
  const [user, setUser] = useState(null);

  if (token) {
    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  }

  useEffect(() => {
    async function fetch() {
      if (token) {
        axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
        window.localStorage.setItem(tokenName, token);
        setUser(jwtDecode(token));
      } else {
        delete axios.defaults.headers.common['Authorization'];
        window.localStorage.removeItem(tokenName);
        setUser(null);
      }
    }
    fetch();
  }, [token]);

  const defaultContext = {
    token,
    setToken,
    user,
    setUser,
  };

  return (
    <AuthContext.Provider value={defaultContext}>
      {children}
    </AuthContext.Provider>
  );
};
