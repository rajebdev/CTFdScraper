const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const axios = require('axios');
const { joinPath, baseURL } = require('../utils/path');

axios.defaults.timeout = 1000;
const usersBaseURL = joinPath(baseURL, 'users/');

exports.register = async function (req, res, next) {
    try {
        const { username, password } = req.body;
        const hash = crypto.createHash('sha256').update(password).digest('hex');
        const response = await axios({
            method: 'post',
            url: usersBaseURL,
            data: { username, password: hash},
        });
        return res.json(response.data);
    } catch (err) {
        if (err.response) {
            return res.status(err.response.status).json(err.response.data);
        }
        return res.status(500);
    }
}

exports.login = async function (req, res, next) {
    try {
        const { username, password } = req.body;
        const response = await axios({
            method: 'get',
            url: joinPath(usersBaseURL, username),
        });
        const user = response.data && response.data.data;
        const hash = crypto.createHash('sha256').update(password).digest('hex');
        if (!user || user.password !== hash) {
            return res.status(401).json({errors: ['Invalid username or password']});
        }
        if (!user.id) {
            return res.status(500);
        }
        const payload = {id: user.id, username: user.username};
        const token = jwt.sign(payload, process.env.JWT_SECRET);
        return res.json({data: {token}});
    } catch (err) {
        if (err.response) {
            return res.status(err.response.status).json(err.response.data);
        }
        return res.status(500);
    }
}
