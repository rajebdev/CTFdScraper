const path = require('path');
const express = require('express');
const jwt = require('express-jwt');

const notes = require('./routes/notes');
const users = require('./routes/users');

const app = express();
const port = 3000;
const checkJwt = jwt({secret: process.env.JWT_SECRET});

app.use(express.json());
app.use(express.static(path.join(__dirname, 'client/build')));

app.get('/api/notes', checkJwt, notes.getNotes);
app.get('/api/notes/:id', checkJwt, notes.getNote);
app.post('/api/notes', checkJwt, notes.createNote);

app.post('/api/register', users.register);
app.post('/api/login', users.login);

app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'client/build/index.html'));
});

const server = app.listen(port, () => {
    console.log(`Serving on http://localhost:${port}/`);
});

const signals = ['SIGHUP', 'SIGINT', 'SIGTERM'];
for (const signal of signals) {
    process.on(signal, () => {
        server.close(() => {
            process.exit(1);
        });
    });
}
